﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis;
using Mono2MicroAppFinal.Common;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Xml.Linq;
using System.Text.Json;
using System.ComponentModel;
using System.Reflection.Metadata;
using System.Security.Claims;
using System.Net.Http;
using System.Collections;
using Newtonsoft.Json;

namespace Mono2MicroAppFinal.MicroServiceCreator
{
    internal class MicroProjectCreatorService
    {
        public List<ProjectSolutionOverallClassFileNameAndDependecy> allClassAndDependencydata = null;
        private string targetFramework = "7.0";
        public MicroProjectCreatorService() { }
        public MicroProjectCreatorService(List<ProjectSolutionOverallClassFileNameAndDependecy> _allClassAndDependencydata, string _targetFramework)
        {
            allClassAndDependencydata = _allClassAndDependencydata;
            targetFramework = _targetFramework;
        }
        public void CreateMicroserviceProject(string directory, string microserviceName)
        {
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            // Use dotnet CLI to create a new web API project
            //RunCommand("dotnet", $"new webapi -n {microserviceName} -f net7.0", directory);
            CreateProjectAndAddSolution(directory, microserviceName);
        }

        public void CopyAndModifyComponentsToMicroserviceOld(string serviceDirectory, List<string> components, string newNamespace)
        {
            // Implement logic to copy relevant files to the new microservice project directory
            foreach (var component in components)
            {
                string oldNameSpace = string.Empty;
                string sourceFile = FindSourceFileForComponent(component); // Implement this method to locate files
                string destinationFile = string.Empty;
                string className = string.Empty;
                if (!string.IsNullOrEmpty(sourceFile))
                {
                    if (File.Exists(sourceFile))
                    {
                        string[] splitComponent = component.Split(".");
                        oldNameSpace = splitComponent.Length >= 3 ? splitComponent[0] : "";
                        string subFolderName = splitComponent.Length >= 3 ? splitComponent[1] : "";
                        className = splitComponent.LastOrDefault();
                        destinationFile = Path.Combine(serviceDirectory, Path.GetFileName(sourceFile));
                        if (!string.IsNullOrEmpty(subFolderName))
                        {
                            string subDirectory = Path.Combine(serviceDirectory, subFolderName);
                            if (!Directory.Exists(subDirectory))
                            {
                                Directory.CreateDirectory(subDirectory);
                            }
                            destinationFile = Path.Combine(subDirectory, Path.GetFileName(sourceFile));
                        }

                        File.Copy(sourceFile, destinationFile, true);

                        // Modify the namespace and using statements in the copied file
                        //newNamespace+ (string.IsNullOrEmpty(subFolderName) ? "" : "." + subFolderName)
                        string subNameSpace = (string.IsNullOrEmpty(subFolderName) ? "" : "." + subFolderName);
                        ModifyNamespaceAndUsingsInFile(destinationFile, newNamespace, subNameSpace, oldNameSpace, className);
                        Console.WriteLine($"Copied and modified {component} to {serviceDirectory}");
                    }
                }
            }
        }

        public async Task<HashSet<string>> CopyAndModifyComponentsToMicroservice(string serviceDirectory, List<string> components, string newNamespace)
        {
            HashSet<string> requiredNamespaces = new HashSet<string>();
            CommonServices.LogWrite($"{serviceDirectory} start CopyAndModifyComponentsToMicroservice");
            foreach (var component in components)
            {
                string oldNameSpace = string.Empty;
                string sourceFile = FindSourceFileForComponent(component); // Implement this method to locate files
                CommonServices.LogWrite($"{component} FindSourceFileForComponent sourcefile path {sourceFile}");
                string className = string.Empty;
                string destinationFile = string.Empty;
                if (!string.IsNullOrEmpty(sourceFile))
                {
                    if (File.Exists(sourceFile))
                    {
                        string[] splitComponent = component.Split(".");
                        oldNameSpace = splitComponent.Length >= 3 ? splitComponent[0] : "";
                        string subFolderName = splitComponent.Length >= 3 ? splitComponent[1] : "";
                        className = splitComponent.LastOrDefault();
                        //destinationFile = Path.Combine(serviceDirectory, Path.GetFileName(sourceFile));
                        destinationFile = Path.Combine(serviceDirectory, className + ".cs");
                        if (!string.IsNullOrEmpty(subFolderName))
                        {
                            string subDirectory = Path.Combine(serviceDirectory, subFolderName);
                            if (!Directory.Exists(subDirectory))
                            {
                                Directory.CreateDirectory(subDirectory);
                            }
                            destinationFile = Path.Combine(subDirectory, className + ".cs");
                        }
                        File.Copy(sourceFile, destinationFile, true);
                        CommonServices.LogWrite($"{sourceFile}  File.Copy(sourceFile, destinationFile, true)  {destinationFile}");
                        // Modify the namespace and using statements in the copied file
                        //newNamespace+ (string.IsNullOrEmpty(subFolderName) ? "" : "." + subFolderName)
                        string subNameSpace = (string.IsNullOrEmpty(subFolderName) ? "" : "." + subFolderName);
                        ModifyNamespaceAndUsingsInFile(destinationFile, newNamespace, subNameSpace, oldNameSpace, className);
                        CommonServices.LogWrite($" ModifyNamespaceAndUsingsInFile(destinationFile {destinationFile}, newNamespace {newNamespace},subNameSpace {subNameSpace},oldNameSpace {oldNameSpace});");

                        CommonServices.LogWrite($"Copied and modified {component} to {serviceDirectory}");
                        Console.WriteLine($"Copied and modified {component} to {serviceDirectory}");

                        requiredNamespaces.UnionWith(AnalyzeClassFileForUsings(sourceFile, oldNameSpace));
                    }
                }
            }
            Console.WriteLine($"\n\n --------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine($"\n\n {serviceDirectory} =>,\n\n Please validate and add following packages =>  \n\n");
            Console.WriteLine(JsonConvert.SerializeObject(requiredNamespaces, Formatting.Indented));
            Console.WriteLine($"\n\n --------------------------------------------------------------------------------------------------------------------------");


            CommonServices.LogWrite($"\n\n --------------------------------------------------------------------------------------------------------------------------");
            CommonServices.LogWrite($"\n\n {serviceDirectory} => \n\n Please validate and add following packages =>  \n\n");
            CommonServices.LogWrite(JsonConvert.SerializeObject(requiredNamespaces, Formatting.Indented));
            CommonServices.LogWrite($"\n\n --------------------------------------------------------------------------------------------------------------------------");


            #region Add Project Reference Code Dot not Delete
            //// Step 2: Dynamically Discover Assemblies or NuGet Packages
            //HashSet<string> requiredAssemblies = new HashSet<string>();
            //foreach (var ns in requiredNamespaces)
            //{
            //    if (!CommonServices.IsExcludeDefaultLibrary(ns))
            //    {
            //        string assembly = await FindNuGetPackageByNamespace(ns);
            //        if (!string.IsNullOrEmpty(assembly))
            //        {
            //            requiredAssemblies.Add(assembly);
            //        }
            //    }
            //}
            //Console.WriteLine($"{serviceDirectory} Required Assenblies to add reference  => " + JsonSerializer.Serialize(requiredAssemblies));
            //CommonServices.LogWrite($"{serviceDirectory} Required Assenblies to add reference  => " + JsonSerializer.Serialize(requiredAssemblies));
            //// Step 3: Add References to the Project File
            //if (requiredAssemblies.Count() > 0)
            //{

            //    AddReferencesToProjectFile(serviceDirectory, requiredAssemblies);
            //    Console.WriteLine("Required references have been added to the project.");
            //    CommonServices.LogWrite($"{serviceDirectory} Required references have been added to the project.");
            //}

            #endregion 

            CommonServices.LogWrite($"{serviceDirectory} end CopyAndModifyComponentsToMicroservice");

            return requiredNamespaces;
        }

        //private HashSet<string> AnalyzeClassFileForUsings(string classFilePath)
        //{
        //    HashSet<string> namespaces = new HashSet<string>();

        //    string fileContent = File.ReadAllText(classFilePath);
        //    SyntaxTree syntaxTree = CSharpSyntaxTree.ParseText(fileContent);
        //    CompilationUnitSyntax root = syntaxTree.GetCompilationUnitRoot();

        //    foreach (var usingDirective in root.Usings)
        //    {
        //        namespaces.Add(usingDirective.Name.ToString());
        //    }

        //    return namespaces;
        //}

        private async Task<string> FindNuGetPackageByNamespace(string namespaceName)
        {
            CommonServices.LogWrite($"Fetching NuGet package for namespace '{namespaceName}' ");
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    // NuGet search query to find packages related to the namespace
                    string query = $"https://api.nuget.org/v3/search?q={namespaceName.ToLower()}&prerelease=false&take=1";
                    //string query = $"https://api.nuget.org/v3/registration5-gz-semver2/{namespaceName.ToLower()}/index.json";
                    CommonServices.LogWrite($"query =>  '{query}' ");
                    HttpResponseMessage response = await client.GetAsync(query);
                    response.EnsureSuccessStatusCode();

                    var jsonResponse = await response.Content.ReadAsStringAsync();
                    var nugetResponse = JsonConvert.DeserializeObject<NuGetSearchResult>(jsonResponse);

                    if (nugetResponse?.data?.Length > 0)
                    {
                        // Return the first matched package ID
                        return nugetResponse.data[0].id;
                    }

                    //// Construct the search URL
                    //string url = $"https://api.nuget.org/v3/registration5-gz-semver2/{namespaceName.ToLower()}/index.json";
                    //CommonServices.LogWrite($"url =>  '{url}' ");
                    //// Make the HTTP GET request
                    //var response = await client.GetAsync(url);

                    //if (response.IsSuccessStatusCode)
                    //{
                    //    var responseBody = await response.Content.ReadAsStringAsync();

                    //    Console.WriteLine(responseBody); // You can parse this JSON as needed
                    //}
                    //else
                    //{
                    //    Console.WriteLine($"Failed to retrieve package info. Status code: {response.StatusCode}");
                    //}
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error fetching NuGet package for namespace '{namespaceName}': {ex.Message}");
                    CommonServices.LogWrite($"Error fetching NuGet package for namespace '{namespaceName}': {ex.Message}");
                }
            }

            return null; // Return null if no package is found
        }

        private void AddReferencesToProjectFile(string projectFilePath, HashSet<string> requiredAssemblies)
        {
            XDocument projectXml = XDocument.Load(projectFilePath);
            XElement projectElement = projectXml.Element("Project");
            if (projectElement == null) return;

            XElement itemGroupElement = projectElement.Elements("ItemGroup").FirstOrDefault(e => e.Elements("PackageReference").Any());

            if (itemGroupElement == null)
            {
                itemGroupElement = new XElement("ItemGroup");
                projectElement.Add(itemGroupElement);
            }

            foreach (var assembly in requiredAssemblies)
            {
                if (!itemGroupElement.Elements("PackageReference")
                                     .Any(e => e.Attribute("Include")?.Value == assembly))
                {
                    itemGroupElement.Add(new XElement("PackageReference",
                        new XAttribute("Include", assembly),
                        new XElement("Version", "latest"))); // Replace "latest" with the desired version
                }
            }

            projectXml.Save(projectFilePath);
        }

        private HashSet<string> AnalyzeClassFileForUsings(string classFilePath, string oldProjectName)
        {
            HashSet<string> namespaces = new HashSet<string>();

            // Read the content of the class file
            string fileContent = File.ReadAllText(classFilePath);

            // Parse the content to a syntax tree
            SyntaxTree syntaxTree = CSharpSyntaxTree.ParseText(fileContent);

            // Get the root node of the syntax tree
            CompilationUnitSyntax root = syntaxTree.GetCompilationUnitRoot();

            // Extract namespaces from using directives
            foreach (var usingDirective in root.Usings)
            {
                string name = usingDirective.Name.ToString();
                //!CommonServices.IsExcludeDefaultLibrary(name) &&
                if (!name.Contains(oldProjectName))
                    namespaces.Add(name);
            }

            // Optionally, filter by class name or any specific criteria

            return namespaces;
        }

        public void ModifyNamespaceAndUsingsInFile(string filePath, string newNamespace, string newSubNameSpace, string oldNamespace, string className)
        {
            string fileContent = File.ReadAllText(filePath);

            StringBuilder newClassContent = new StringBuilder();
            // Parse the content to a syntax tree
            SyntaxTree syntaxTree = CSharpSyntaxTree.ParseText(fileContent);

            // Get the root node of the syntax tree
            CompilationUnitSyntax root = syntaxTree.GetCompilationUnitRoot();

            // Regex to match and replace the namespace declaration
            string updatedContent = fileContent;
            // Regex to match and replace using statements pointing to the old namespace
            if (!string.IsNullOrEmpty(oldNamespace))
            {
                string oldNamespacePattern = @"using\s+[\w\.]+;";
                updatedContent = Regex.Replace(updatedContent, oldNamespacePattern, match =>
                {
                    string usingStatement = match.Value; // e.g., "using OldNamespace.SubNamespace;"
                    string newUsingStatement = usingStatement.Replace(oldNamespace, newNamespace); // Replace the old namespace with the new one
                    newClassContent.Append(newUsingStatement + "  \n");
                    return newUsingStatement;
                });
            }

            var classes = root.DescendantNodes().OfType<ClassDeclarationSyntax>();
            if (classes.Count() > 1)
            {
                foreach (var @class in classes)
                {
                    if (@class.Identifier.Text == className)
                    {
                        string content = $"\n namespace {newNamespace + newSubNameSpace} \n" + "{  \n" + @class.ToString() + "\n} ";
                        newClassContent.Append(content);
                    }
                }
                fileContent = newClassContent.ToString();
            }
            else
            {
                var interfaces = root.DescendantNodes().OfType<InterfaceDeclarationSyntax>();
                if (interfaces.Count() > 1)
                {
                    foreach (var @interface in interfaces)
                    {
                        if (@interface.Identifier.Text == className)
                        {
                            string content = $"\n namespace {newNamespace + newSubNameSpace} \n" + "{  \n" + @interface.ToString() + "\n} ";
                            newClassContent.Append(content);
                        }
                    }
                    fileContent = newClassContent.ToString();
                }
            }


            // Regex to match and replace the namespace declaration
            updatedContent = Regex.Replace(fileContent, @"namespace\s+[\w\.]+", $"namespace {newNamespace + newSubNameSpace}");
            // Regex to match and replace using statements pointing to the old namespace
            if (!string.IsNullOrEmpty(oldNamespace))
            {
                string oldNamespacePattern = @"using\s+[\w\.]+;";
                updatedContent = Regex.Replace(updatedContent, oldNamespacePattern, match =>
                {
                    string usingStatement = match.Value; // e.g., "using OldNamespace.SubNamespace;"
                    string newUsingStatement = usingStatement.Replace(oldNamespace, newNamespace); // Replace the old namespace with the new one                    
                    return newUsingStatement;
                });
            }

            File.WriteAllText(filePath, updatedContent);
        }

        public string FindSourceFileForComponent(string componentName)
        {
            // Implement logic to locate the actual file path of the component
            // For example, you might search in a specific directory or solution folder
            string componentFilePath = GetSourceFileForComponent(componentName);
            return string.IsNullOrEmpty(componentFilePath) ? $"{componentName}.cs" : componentFilePath; // This is just a placeholder, adjust as needed
        }
        public string GetSourceFileForComponent(string componentName)
        {
            if (allClassAndDependencydata != null)
            {
                var classData = allClassAndDependencydata.FirstOrDefault(xx => xx.ClassFullName == componentName);
                if (classData != null) { return classData.ClassFullPath; }
            }
            return "";
        }
        public string GetSourceFileClassName(string componentName)
        {
            if (allClassAndDependencydata != null)
            {
                var classData = allClassAndDependencydata.FirstOrDefault(xx => xx.ClassFullName == componentName);
                if (classData != null) { return classData.ClassName; }
            }
            return "";
        }

        public void RunCommand(string fileName, string arguments, string workingDirectory)
        {
            var processInfo = new ProcessStartInfo
            {
                FileName = fileName,
                Arguments = arguments,
                WorkingDirectory = workingDirectory,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using (var process = Process.Start(processInfo))
            {
                process.OutputDataReceived += (sender, e) => Console.WriteLine(e.Data);
                process.ErrorDataReceived += (sender, e) => Console.WriteLine("ERROR: " + e.Data);
                process.BeginOutputReadLine();
                process.BeginErrorReadLine();
                process.WaitForExit();
            }
        }

        public void CreateProjectAndAddSolution(string directory, string microserviceName)
        {
            string directoryPath = directory; // Replace with your path
            string solutionName = microserviceName;
            string projectName = microserviceName;
            targetFramework = string.IsNullOrEmpty(targetFramework) ? "" : targetFramework;
            //-f net{ targetFramework}, -f net7.0
            // Combine all commands into a single command string
            string combinedCommands =
                $"dotnet new sln -n {solutionName} && " +
                $"dotnet new webapi -n {projectName} {targetFramework} && " +
                $"dotnet sln add {projectName}/{projectName}.csproj";

            // Execute the combined command
            ExecuteCommand(combinedCommands, directoryPath);



            Console.WriteLine("Solution and project created successfully.");
        }

        private void ExecuteCommand(string command, string workingDirectory)
        {
            try
            {
                // Initialize the process with necessary settings
                var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = "cmd.exe",
                        Arguments = $"/c {command}",
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        UseShellExecute = false,
                        CreateNoWindow = true,
                        WorkingDirectory = workingDirectory
                    }
                };

                // Start the process and wait for it to exit
                process.Start();
                process.WaitForExit();

                // Read output and errors
                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();

                // Display the output
                Console.WriteLine(output);
                CommonServices.LogWrite($"{workingDirectory}   output while creating projects  => " + output);
                if (!string.IsNullOrEmpty(error))
                {
                    Console.WriteLine($"Error: {error}");
                    CommonServices.LogWrite($"{workingDirectory}   Error while creating projects  => " + error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                CommonServices.LogWrite($"{workingDirectory}  exception  => " + ex.ToString());
            }
        }


    }
}
