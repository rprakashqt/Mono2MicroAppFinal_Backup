﻿
using Mono2MicroAppFinal.Common;
using Mono2MicroAppFinal.MicroServiceCreator;
using Mono2MicroAppFinal.CodeAnalyzer;
using System.Configuration;
using System.Text.Json;
using Newtonsoft.Json;
namespace Mono2MicroAppFinal
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            try
            {
                if (args.Length <= 0)
                {
                    args = new string[1];
                    //args[0] = "codeanalysis";
                    args[0] = "createmicroservices";
                }

                CommonServices.LogWrite(JsonConvert.SerializeObject(args));
                if (!string.IsNullOrEmpty(args[0]))
                {
                    if (args[0] == "codeanalysis")
                    {
                        await Call_CodeAnalyzer(args);
                    }
                    else
                    {
                        await CreateMicroServices(args);
                    }
                }
                else
                {
                    CommonServices.LogWrite("Invalid arguments");
                    Console.WriteLine("Failed");
                    return;
                }
            }
            catch (Exception ex)
            {
                CommonServices.LogWrite(ex.ToString());
                Console.WriteLine("Failed");
                return;
            }
        }

        public static async Task Call_CodeAnalyzer(string[] args)
        {

            string solutionPath = string.Empty;
            if (args.Length > 1)
                solutionPath = args[1].ToString();
            else
            {
                Console.WriteLine("\n     Enter Solution path to analyse :  ");
                solutionPath = Console.ReadLine();
            }

            string monolithSolutionName = Path.GetFileNameWithoutExtension(solutionPath);
            string fileTimeLog = CommonServices.LogFile_Timer();
            string outputRootDir = ConfigurationManager.AppSettings["DOTFILEPATH"].ToString();
            string baseOutFilePath = Path.Combine(outputRootDir, monolithSolutionName + "_" + fileTimeLog);
            CommonServices.CreateDictory(baseOutFilePath);
            string dotFilePath = Path.Combine(baseOutFilePath, "dotdigraph.dot");
            CommonServices.logFilePath = baseOutFilePath;


            var analyzer = new DependencyAnalyzer();
            //Console.WriteLine("\n     Started  Analyze Code Dependencies");
            CommonServices.LogWrite(" Started  Analyze Code Dependencies");
            var codeAnalysisReponse = await analyzer.AnalyzeCodeDependencies(solutionPath);
            //Console.WriteLine("\n     Ended  Analyze Code Dependencies");
            CommonServices.LogWrite(" Ended  Analyze Code Dependencies");

            CommonServices.LogWrite(" codeAnalysisReponse  => " + JsonConvert.SerializeObject(codeAnalysisReponse));

            if (codeAnalysisReponse == null)
            {
                Console.WriteLine("Failed");
                return;
            }

            string overallClassAndDependencyFilePath = Path.Combine(baseOutFilePath, "AllClassDependencies.json");
            CommonServices.WriteJsonFile(overallClassAndDependencyFilePath, JsonConvert.SerializeObject(codeAnalysisReponse.overallClassesAndDependencies, Formatting.Indented));

            //Console.WriteLine("\n     Started  Generate Dot File");
            CommonServices.LogWrite("\n     Started  Generate Dot File");
            var umlGenerator = new UmlDiagramGenerator();
            umlGenerator.GenerateDotFile(codeAnalysisReponse.dependencies, dotFilePath);
            CommonServices.LogWrite("\n     Ended  Generate Dot File");

            CommonServices.LogWrite(dotFilePath + " | " + overallClassAndDependencyFilePath);

            Console.WriteLine(dotFilePath + "|" + overallClassAndDependencyFilePath);
        }

        public static async Task CreateMicroServices(string[] args)
        {

            string microserviceOutputDir = ConfigurationManager.AppSettings["MICROSERVICEOUTPUTDIR"].ToString();
            string targetFramework = ConfigurationManager.AppSettings["TargetFramework"].ToString();


            string solutionFilePath = @"C:\Work\CONGIX_WORKFLOW\Source Code-TML-Phase2Safe\API\DOT_NET_CORE_API\WorkflowAPI\WorkflowAPI.sln";
            string classDependencyJsonFilePath = @"C:\Work\TSS\POC\Mono2Micro\Mono2MicroAppFinal\Output\AllClassDependencies.json";
            string microServiceJsonFilePath = @"C:\Work\TSS\POC\Mono2Micro\Mono2MicroAppFinal\Output\Microservice_suggestion.json";
            if (args.Length >= 4)
            {
                solutionFilePath = args[1];
                classDependencyJsonFilePath = args[2];
                microServiceJsonFilePath = args[3];
            }
            var dicCommunity = CommonServices.JsonToDictionary(microServiceJsonFilePath);
            var suggestions = new List<MicroserviceSuggestion>();
            if (dicCommunity != null)
            {
                suggestions = new List<MicroserviceSuggestion>();
                foreach (var item in dicCommunity)
                {
                    MicroserviceSuggestion micrSuggestion = new MicroserviceSuggestion
                    {
                        MicroserviceName = item.Key,
                        Components = item.Value

                    };
                    suggestions.Add(micrSuggestion);
                }
            }


            string solutionName = Path.GetFileNameWithoutExtension(solutionFilePath);
            string baseDirectory = Path.Combine(microserviceOutputDir, solutionName + "_" + CommonServices.LogFile_Timer());
            CommonServices.CreateDictory(baseDirectory);

            CommonServices.logFilePath = baseDirectory;

            var allClassAndDependencydata = CommonServices.ReadJsonFile<List<ProjectSolutionOverallClassFileNameAndDependecy>>(classDependencyJsonFilePath);
            var objCreator = new MicroProjectCreatorService(allClassAndDependencydata, targetFramework);

            var microserviceAndPackageList = new List<MicroserviceProjectAndAddPackageList>();

            foreach (var suggestion in suggestions)
            {

                CommonServices.LogWrite("Creating Microservices => " + suggestion.MicroserviceName);
                string serviceDirectory = Path.Combine(baseDirectory, suggestion.MicroserviceName);

                CommonServices.LogWrite("Calling CreateMicroserviceProject => " + suggestion.MicroserviceName);
                objCreator.CreateMicroserviceProject(serviceDirectory, suggestion.MicroserviceName);
                CommonServices.LogWrite("Ended CreateMicroserviceProject => " + suggestion.MicroserviceName);

                CommonServices.LogWrite("Calling CopyAndModifyComponentsToMicroservice => " + suggestion.MicroserviceName);
                serviceDirectory = Path.Combine(serviceDirectory, suggestion.MicroserviceName);
                var packageNameList = await objCreator.CopyAndModifyComponentsToMicroservice(serviceDirectory, suggestion.Components, suggestion.MicroserviceName);
                CommonServices.LogWrite("Calling CopyAndModifyComponentsToMicroservice => " + suggestion.MicroserviceName);

                microserviceAndPackageList.Add(new MicroserviceProjectAndAddPackageList
                {
                    MicroserviceName = suggestion.MicroserviceName,
                    PackageNameList = packageNameList
                });

                CommonServices.LogWrite("End of creating Microservices => " + suggestion);
            }

           

            CommonServices.LogWrite("\n\n Microservice projects generated successfully.");
            CommonServices.LogWrite($"\n\n --------------------------------------------------------------------------------------------------------------------------");
            CommonServices.LogWrite("\n\n Required to do following action manually.");
            CommonServices.LogWrite("\n 1) Do manual classification on appsettings.json file and move to respective Microservice Project");
            CommonServices.LogWrite("\n 2) Do manual classification on Program.cs and Startup.cs file and move respective Microservice Project");
            CommonServices.LogWrite("\n 3) Add Nuget Package Reference manually if missing.");
            CommonServices.LogWrite("\n" + JsonConvert.SerializeObject(microserviceAndPackageList, Formatting.Indented));
            CommonServices.LogWrite($"\n\n --------------------------------------------------------------------------------------------------------------------------");

            Console.WriteLine("\n\n Microservice projects generated successfully.");
            Console.WriteLine($"\n\n --------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("\n\n Required to do following action manually.");           
            Console.WriteLine("\n 1) Do manual classification on appsettings.json file and move to respective Microservice Project");
            Console.WriteLine("\n 2) Do manual classification on Program.cs and Startup.cs file and move respective Microservice Project");
            Console.WriteLine("\n 3) Add Nuget Package Reference manually if missing.");
            Console.WriteLine("\n" + JsonConvert.SerializeObject(microserviceAndPackageList, Formatting.Indented));
            Console.WriteLine($"\n\n --------------------------------------------------------------------------------------------------------------------------");

        }
    }
}
