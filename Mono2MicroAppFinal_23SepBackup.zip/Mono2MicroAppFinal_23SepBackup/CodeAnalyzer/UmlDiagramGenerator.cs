﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using Mono2MicroAppFinal.Common;

namespace Mono2MicroAppFinal.CodeAnalyzer
{
    public class UmlDiagramGenerator
    {
        /// <summary>
        /// Logic to write .Dot file 
        /// </summary>
        /// <param name="projectDependencies"></param>
        /// <param name="dotFilePath"></param>
        public void GenerateDotFile(Dictionary<string, ProjectDependency> projectDependencies, string dotFilePath)
        {
            var dotContent = GenerateLinearDotContent(projectDependencies);
            File.WriteAllText(dotFilePath, dotContent);

        }
        /// <summary>
        /// digraph generator logic with out subgraph
        /// </summary>
        /// <param name="projectDependencies"></param>
        /// <returns></returns>
        private string GenerateLinearDotContent(Dictionary<string, ProjectDependency> projectDependencies)
        {
            var dot = new System.Text.StringBuilder();
            dot.AppendLine("digraph G {");
            foreach (var project in projectDependencies)
            {
                foreach (var @class in project.Value.Classes)
                {
                    foreach (var dependency in @class.Value.Dependencies)
                    {
                        dot.AppendLine($"    {@class.Key} -> {dependency};");
                    }
                }
            }

            dot.AppendLine("}");
            return dot.ToString();
        }

        /// <summary>
        /// dot file contains with subgraph
        /// </summary>
        /// <param name="projectDependencies"></param>
        /// <returns></returns>
        private string GenerateDotContent(Dictionary<string, ProjectDependency> projectDependencies)
        {
            var dot = new System.Text.StringBuilder();
            dot.AppendLine("digraph G {");

            foreach (var project in projectDependencies)
            {
                dot.AppendLine($"subgraph cluster_{project.Key.Replace('.', '_')} {{");
                dot.AppendLine($"    label = \"{project.Key}\";");
                dot.AppendLine($"    color = blue;");

                foreach (var @class in project.Value.Classes)
                {
                    dot.AppendLine($"    \"{project.Key}.{@class.Key}\" [label=\"{@class.Key}\"];");
                    foreach (var dependency in @class.Value.Dependencies)
                    {
                        dot.AppendLine($"    \"{project.Key}.{@class.Key}\" -> \"{dependency}\";");
                    }
                }

                dot.AppendLine("}");
            }

            dot.AppendLine("}");
            return dot.ToString();
        }
    }
}
