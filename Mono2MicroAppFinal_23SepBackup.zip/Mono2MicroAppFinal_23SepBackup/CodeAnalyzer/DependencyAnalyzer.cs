﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.MSBuild;
using Mono2MicroAppFinal.Common;

namespace Mono2MicroAppFinal.CodeAnalyzer
{
    public class DependencyAnalyzer
    {
        public async Task<AnalyzeCodeDependencies_Response> AnalyzeCodeDependencies(string solutionPath)
        {
            var response = new AnalyzeCodeDependencies_Response();
            response.overallClassesAndDependencies = new List<ProjectSolutionOverallClassFileNameAndDependecy>();

            using (var workspace = MSBuildWorkspace.Create())
            {
                workspace.WorkspaceFailed += (sender, e) =>
                {
                    //Console.WriteLine($"Workspace failed: {e.Diagnostic.Message}");
                    CommonServices.LogWrite($"Workspace failed: {e.Diagnostic.Message}");
                };

                var solution = await workspace.OpenSolutionAsync(solutionPath);
                var dependencies = new Dictionary<string, ProjectDependency>();

                foreach (var project in solution.Projects)
                {

                    var projectDependency = new ProjectDependency { ProjectName = project.Name };

                    foreach (var document in project.Documents)
                    {
                        var root = await document.GetSyntaxRootAsync();
                        var model = await document.GetSemanticModelAsync();

                        var classes = root.DescendantNodes().OfType<ClassDeclarationSyntax>();

                        if (classes != null && classes.Count() > 0)
                        {

                            foreach (var @class in classes)
                            {
                                var className = model.GetDeclaredSymbol(@class).ToString();                             

                                if (!projectDependency.Classes.ContainsKey(className))
                                {
                                    projectDependency.Classes[className] = new ClassDependency { ClassName = className };
                                }

                                var classDependencies = @class.DescendantNodes()
                                    .OfType<IdentifierNameSyntax>()
                                    .Select(id => model.GetSymbolInfo(id).Symbol)
                                    .Where(symbol => symbol != null && symbol.Kind == SymbolKind.NamedType)
                                    .Select(symbol => symbol.ToString())
                                    .Where(name => !CommonServices.IsFrameworkClass(name) && !CommonServices.ReservedKeywords.Contains(name) && !CommonServices.IsAttribute(name));

                                foreach (var dependency in classDependencies)
                                {
                                    projectDependency.Classes[className].Dependencies.Add(dependency);
                                }

                                response.overallClassesAndDependencies.Add(new ProjectSolutionOverallClassFileNameAndDependecy
                                {
                                    ProjectName = project.Name,
                                    ClassName = CommonServices.GetLastIndexValue(className, "."),
                                    ClassFullName = className,
                                    ClassFullPath = document.FilePath,
                                    Dependencies = projectDependency.Classes[className].Dependencies

                                });

                            }
                        }
                        else
                        {
                            var interfaces = root.DescendantNodes().OfType<InterfaceDeclarationSyntax>();
                            foreach (var @interface in interfaces)
                            {
                                var interfaceName = model.GetDeclaredSymbol(@interface).ToString();

                                if (!projectDependency.Classes.ContainsKey(interfaceName))
                                {
                                    projectDependency.Classes[interfaceName] = new ClassDependency { ClassName = interfaceName };
                                }

                                var classDependencies = @interface.DescendantNodes()
                                    .OfType<IdentifierNameSyntax>()
                                    .Select(id => model.GetSymbolInfo(id).Symbol)
                                    .Where(symbol => symbol != null && symbol.Kind == SymbolKind.NamedType)
                                    .Select(symbol => symbol.ToString())
                                    .Where(name => !CommonServices.IsFrameworkClass(name) && !CommonServices.ReservedKeywords.Contains(name) && !CommonServices.IsAttribute(name));

                                foreach (var dependency in classDependencies)
                                {
                                    projectDependency.Classes[interfaceName].Dependencies.Add(dependency);
                                }

                                response.overallClassesAndDependencies.Add(new ProjectSolutionOverallClassFileNameAndDependecy
                                {
                                    ProjectName = project.Name,
                                    ClassName = CommonServices.GetLastIndexValue(interfaceName, "."),
                                    ClassFullName = interfaceName,
                                    ClassFullPath = document.FilePath,
                                    Dependencies = projectDependency.Classes[interfaceName].Dependencies

                                });
                            }
                        }
                    }

                    dependencies[project.Name] = projectDependency;
                }
                response.dependencies = dependencies;

                return response;
            }
        }

    }
}
