Create .exe for Different OS
    1) pip install pyinstaller

    2) pyinstaller --onefile --windowed --add-data "appsettings.json;." Mono2MicroAppFinal.py

    3) pyinstaller --windowed --add-data "appsettings.json;." Mono2MicroAppFinal.py