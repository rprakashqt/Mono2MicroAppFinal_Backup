from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QProgressBar, QHBoxLayout
from PyQt6.QtGui import QPixmap
from PyQt6.QtCore import Qt

class ProgressBarWidget(QWidget):
    def __init__(self, icon_path: str = None, initial_text: str = "Processing..."):
        super().__init__()
        
        # Set up the main layout
        self.layout = QVBoxLayout(self)
        
        # Optional icon
        if icon_path:
            self.icon_label = QLabel(self)
            self.icon_label.setPixmap(QPixmap(icon_path))
            self.icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.layout.addWidget(self.icon_label)
        
        # Custom text label
        self.text_label = QLabel(initial_text, self)
        self.text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.text_label.setWordWrap(True)
        self.layout.addWidget(self.text_label)

        # Progress bar
        self.progress_bar = QProgressBar(self)
        self.progress_bar.setRange(0, 0)  # Indeterminate mode
        self.layout.addWidget(self.progress_bar)

        # Center the progress bar and text
        self.setLayout(self.layout)
        self.setFixedSize(300, 150)
        self.setWindowTitle("Progress")

    def show_progress(self, text: str = None):
        if text:
            self.text_label.setText(text)            
        self.show()

    def hide_progress(self):
        self.hide()
