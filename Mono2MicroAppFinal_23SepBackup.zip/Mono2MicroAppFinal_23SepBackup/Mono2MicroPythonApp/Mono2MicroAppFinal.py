#step 1 set python environment : python -m venv venv
import json
import os
import re
import subprocess
import sys
import threading
#pip install pydot
import pydot
from collections import Counter
#pip install PyQt6
from PyQt6.QtWidgets import (
   QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, 
    QPushButton, QFileDialog, QTreeWidget, QTreeWidgetItem, QComboBox,
    QSpacerItem, QSizePolicy,QScrollArea,QAbstractItemView,QTabWidget,QGridLayout,
    QDialog,QTextEdit,QProgressBar
)

from PyQt6.QtCore import QSize, Qt 
from PyQt6.QtGui import QAction,QPixmap
#pip install networkx
import networkx as nx
from networkx.algorithms.community import greedy_modularity_communities
# pip install python-louvain
import community as community_louvain  # Louvain method for community detection
#pip install qt_material
from qt_material import apply_stylesheet
#pip install matplotlib
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

#pip install pandas
import pandas as pd
#pip install scikit-learn 
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from ProgressBar_Widget import ProgressBarWidget

#pip install pyinstaller


class MicroserviceNameSuggeestion:
    def RemoveReservedString(self,class_name):
        rep = {"Models": "", "Controllers": "","Repository":"","Services":"","Common":"Common","Type":"","list":"","List":"","Request":"", "Response":"","request":"" } # define desired replacements here

        # use these three lines to do the replacement
        rep = dict((re.escape(k), v) for k, v in rep.items()) 
        pattern = re.compile("|".join(rep.keys()))
        class_name = pattern.sub(lambda m: rep[re.escape(m.group(0))], class_name)
        return class_name
    
    def preprocess_text(self,text):
        # Remove special characters, numbers, and convert to lowercase
        text=self.RemoveReservedString(text)
        text = re.sub(r'[^A-Za-z\s]', '', text)
        #text = text.lower()
        return text

    def generate_community_names(self,texts, num_communities=1):
        # Preprocess the text data
        processed_texts = [self.preprocess_text(text) for text in texts]
        
        # Vectorize the text data using TF-IDF
        vectorizer = TfidfVectorizer(stop_words='english',lowercase=False)
        X = vectorizer.fit_transform(processed_texts)
        
        # Apply K-Means clustering
        kmeans = KMeans(n_clusters=num_communities, random_state=42)
        kmeans.fit(X)
        
        # Find the most common terms in each cluster
        terms = vectorizer.get_feature_names_out()
        cluster_labels = kmeans.labels_
        cluster_centers = kmeans.cluster_centers_
        
        community_names = []
        for i in range(num_communities):
            # Get indices of terms sorted by relevance for each cluster
            indices = cluster_centers[i].argsort()[::-1]
            common_terms = [terms[index] for index in indices[:1]]  # Top 3 terms
            community_name = '_'.join(common_terms)
            community_names.append(community_name)
        
        return community_names

class PrepareNetworkDiagram:
    def parse_dot_file(self, dot_file_path):
        """Parse the .dot file to extract nodes and edges."""
        nodes = set()
        edges = []

        try:
            with open(dot_file_path, 'r') as file:
                lines = file.readlines()
                for line in lines:
                    # Parse nodes
                    if '->' not in line and '[' in line:
                        node = line.split('[')[0].strip()
                        nodes.add(node)

                    # Parse edges
                    if '->' in line:
                        source, target = line.split('->')
                        source = source.strip()
                        target = target.split(';')[0].strip()
                        edges.append((source, target))

            print(f"Parsed {len(nodes)} nodes and {len(edges)} edges from {dot_file_path}")
            return nodes, edges
        except FileNotFoundError:
            print(f"Error: File {dot_file_path} not found.")
            return set(), []

    def load_community_json(self,json_file_path):
        """Load community data from the _community.json file."""
        try:
            with open(json_file_path, 'r') as file:
                community_data = json.load(file)
                print(f"Loaded community data from {json_file_path}")
                return community_data
        except FileNotFoundError:
            print(f"Error: File {json_file_path} not found.")
            return {}

    def prepare_relationship_data(self, nodes, edges, community_data):
        """Prepare relationship data comparing nodes and community JSON data."""
        relationship_data = {}

        for community, community_nodes in community_data.items():
            # Filter edges belonging to the community nodes
            community_edges = [
                edge for edge in edges if edge[0] in community_nodes and edge[1] in community_nodes
            ]

            relationship_data[community] = {
                "nodes": community_nodes,
                "edges": community_edges
            }

        print("Relationship data prepared.")
        return relationship_data

    def save_relationship_data(self,relationship_data, output_path):
        """Save relationship data to _relationshipData.json."""
        try:
            with open(output_path, 'w') as file:
                json.dump(relationship_data, file, indent=4)
            print(f"Relationship data saved to {output_path}")
        except Exception as e:
            print(f"Error saving relationship data: {e}")


    def draw_network(relationship_data, output_folder):
        """Draw network diagrams for each community based on relationship data."""
        for community, data in relationship_data.items():
            G = nx.DiGraph()  # Directed graph to match .dot structure

            # Add nodes and edges
            G.add_nodes_from(data['nodes'])
            G.add_edges_from(data['edges'])

            plt.figure(figsize=(10, 8))
            pos = nx.spring_layout(G)  # Spring layout for better visualization
            nx.draw(
                G, pos, with_labels=True, node_color='skyblue', edge_color='gray', 
                node_size=1500, font_size=10, font_weight='bold', arrowsize=20
            )
            plt.title(f"Class Diagram for {community}")

            # Save the diagram as a PNG file in the output folder
            diagram_path = f"{output_folder}/{community}_network.png"
            plt.savefig(diagram_path)
            plt.close()
            print(f"Class diagram saved for {community} at {diagram_path}")

class DraggableNode:
    """Class to handle the dragging functionality for a node."""
    def __init__(self, point, text, canvas):
        self.point = point
        self.text = text
        self.canvas = canvas
        self.press = None
        self.background = None

    def connect(self):
        """Connect to canvas events."""
        self.cidpress = self.canvas.mpl_connect('button_press_event', self.on_press)
        self.cidrelease = self.canvas.mpl_connect('button_release_event', self.on_release)
        self.cidmotion = self.canvas.mpl_connect('motion_notify_event', self.on_motion)

    def on_press(self, event):
        """Handle mouse button press event."""
        if event.inaxes != self.point.axes: return
        contains, _ = self.point.contains(event)
        if not contains: return
        self.press = (self.point.center[0], self.point.center[1]), event.xdata, event.ydata
        self.background = self.canvas.copy_from_bbox(self.point.axes.bbox)

    def on_motion(self, event):
        """Handle mouse motion event."""
        if self.press is None: return
        if event.inaxes != self.point.axes: return
        (x0, y0), xpress, ypress = self.press
        dx = event.xdata - xpress
        dy = event.ydata - ypress
        self.point.center = (x0+dx, y0+dy)
        self.text.set_position((x0+dx, y0+dy))
        self.canvas.restore_region(self.background)
        self.point.axes.draw_artist(self.point)
        self.point.axes.draw_artist(self.text)
        self.canvas.blit(self.point.axes.bbox)

    def on_release(self, event):
        """Handle mouse button release event."""
        self.press = None
        self.canvas.draw()

    def disconnect(self):
        """Disconnect all canvas events."""
        self.canvas.mpl_disconnect(self.cidpress)
        self.canvas.mpl_disconnect(self.cidrelease)
        self.canvas.mpl_disconnect(self.cidmotion)

class ZoomableCanvas(FigureCanvas):
    def __init__(self, figure):
        super().__init__(figure)
        self.figure = figure
        self.ax = figure.axes[0]
        self.zoom_factor = 1.2
        self._is_zooming = False
        self.draggables = []  # To store draggable nodes

        # Connect mouse events
        self.mpl_connect('scroll_event', self.on_scroll)

    def add_draggable(self, point, text):
        """Add draggable functionality to a point."""
        # draggable = DraggableNode(point, text, self)
        # draggable.connect()
        # self.draggables.append(draggable)

    def on_scroll(self, event):
        """Handle mouse wheel scroll for zooming."""
        x, y = event.xdata, event.ydata
        if x is None or y is None:
            return

        # Zoom in or out
        if event.button == 'up':  # Scroll up to zoom in
            scale_factor = self.zoom_factor
        elif event.button == 'down':  # Scroll down to zoom out
            scale_factor = 1 / self.zoom_factor
        else:
            scale_factor = 1

        self.ax.set_xlim([x + (x - self.ax.get_xlim()[0]) / scale_factor,
                          x + (x - self.ax.get_xlim()[1]) / scale_factor])
        self.ax.set_ylim([y + (y - self.ax.get_ylim()[0]) / scale_factor,
                          y + (y - self.ax.get_ylim()[1]) / scale_factor])

        self.draw()

    def save_as_image(self, file_path, format='png'):
        """Export current canvas to image (PDF or PNG)."""
        self.figure.savefig(file_path, format=format)
        print(f"Diagram exported to {file_path}.")

class LoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Mono2Micro APP Login")
        self.setFixedSize(350, 200)  # Set fixed size to 300x250 pixels
        self.initUI()        
        
    def initUI(self):
        main_widget = QWidget(self)
        self.setCentralWidget(main_widget)

        form_layout = QVBoxLayout(main_widget)
        form_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)  # Center the form

        # Username
        self.username_label = QLabel("Username:", self)
        form_layout.addWidget(self.username_label)

        self.username_input = QLineEdit(self)
        form_layout.addWidget(self.username_input)

        # Password
        self.password_label = QLabel("Password:", self)
        form_layout.addWidget(self.password_label)

        self.password_input = QLineEdit(self)
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        form_layout.addWidget(self.password_input)

        # Spacer to push login button down
        spacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)
        form_layout.addItem(spacer)

        # Login button
        self.login_button = QPushButton("Login", self)
        self.login_button.clicked.connect(self.login)
        form_layout.addWidget(self.login_button)

    def login(self):
        self.code_analysis_window = CodeAnalysisWindow()
        self.code_analysis_window.show()
        self.close()

class CodeAnalysisWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Mono2Micro Tranformation APP")
        self.setMinimumSize(QSize(800, 600)) 
        
        # Initialize Loader Dialog        
        self.progress_widget = ProgressBarWidget(icon_path="path/to/icon.png", initial_text="Please wait...")

        self.executable_paths, self.save_paths = self.load_configuration()
        self.community_file_path = None  # Path to the JSON file to be updated
        self.original_communities_data = None  # To hold the original data for reset
        self.community_relationship_data = None  # To hold the community_relationship_data data for render network diagram
        self.relationship_json_path = None # To community_relationship_json path 
        self.dot_file_path=None
        self.All_ClassAndDependencies_Json_File_Path=None               
        self.initUI()
        # self.apply_theme()

    def initUI(self):
        main_widget = QWidget(self)
        
        self.setCentralWidget(main_widget)

        layout = QVBoxLayout(main_widget)        

        # First row - Solution type combobox and solution file path
        row_layout = QHBoxLayout()

        self.solution_type_label = QLabel("Solution Type:", self)
        row_layout.addWidget(self.solution_type_label)

        self.solution_type_combobox = QComboBox(self)
        self.solution_type_combobox.addItems([".Net Web API", "Java Web API"])
        row_layout.addWidget(self.solution_type_combobox)

        self.solution_file_input = QLineEdit(self)
        self.solution_file_input.setPlaceholderText("Solution File Path")
        row_layout.addWidget(self.solution_file_input)

        self.browse_button = QPushButton("Browse", self)
        self.browse_button.clicked.connect(self.browse_file)    
        row_layout.addWidget(self.browse_button)

        #  Proceed button
        self.proceed_button = QPushButton("Proceed", self)
        self.proceed_button.setEnabled(False)
        self.proceed_button.setToolTip("Click to proceed code Analyze")
        self.proceed_button.clicked.connect(self.proceed)
        row_layout.addWidget(self.proceed_button)        

        layout.addLayout(row_layout)

        # # Proceed button
        # self.proceed_button = QPushButton("Proceed", self)
        # self.proceed_button.clicked.connect(self.proceed)
        # layout.addWidget(self.proceed_button)
        # Create tabs
        self.tabs = QTabWidget()
        self.results_tree = QWidget()
        self.network_tab = QWidget() 

        # File processing results with drag-and-drop enabled
        self.results_tree = QTreeWidget(self)
        self.results_tree.setHeaderLabels(["Identified Microservices"])
        self.results_tree.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked)  # Make headers editable
        self.results_tree.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)  # Enable drag and drop
        self.results_tree.itemChanged.connect(self.handle_item_changed)  # Handle autosave on edit
        self.tabs.addTab(self.results_tree, "View Microservices")    

        self.network_tab = QWidget(self)
        #self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(self.network_tab)

        # Scroll area setup
        scroll_area = QScrollArea(self.network_tab)
        scroll_area.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QGridLayout(scroll_content)
        scroll_area.setWidget(scroll_content)

        main_layout.addWidget(scroll_area)
        self.network_tab.diagram_layout = scroll_layout  # Store layout for adding diagrams    
    
        self.tabs.addTab(self.network_tab, "View Class Relationship Diagram")
        self.tabs.currentChanged.connect(self.onTabChange)        
        layout.addWidget(self.tabs)

        #layout.addWidget(self.results_tree)

        # Save and Reset buttons
        button_layout = QHBoxLayout()

        # Add a spacer item to push buttons to the right
        spacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        button_layout.addItem(spacer)
        
        self.save_button = QPushButton("Save", self)        
        self.save_button.setFixedWidth(100)  # Set the width of the Save button   
        self.save_button.setToolTip("Click to save customized Microservice list and relationship diagram data") 
        self.save_button.clicked.connect(self.save_tree_to_json)
        button_layout.addWidget(self.save_button)

        self.reset_button = QPushButton("Reset", self)
        self.reset_button.setToolTip("Click to reset Original Microservice list") 
        self.reset_button.setFixedWidth(100)  # Set the width of the Reset button  
        self.reset_button.clicked.connect(self.reset_tree_view)
        button_layout.addWidget(self.reset_button)

        self.createMicroservices_button = QPushButton("Create Microservices", self)    
        self.createMicroservices_button.setToolTip("Click to create microservices based on the saved dataset")     
        self.createMicroservices_button.setFixedWidth(200)  # Set the width of the Create Microservices button  
        self.createMicroservices_button.clicked.connect(self.create_microservice_popup)
        button_layout.addWidget(self.createMicroservices_button)
        self.enable_disable_bottom_buttons(False)

        layout.addLayout(button_layout)

    def enable_disable_bottom_buttons(self,status=False):
        self.createMicroservices_button.setEnabled(status)
        self.reset_button.setEnabled(status)
        self.save_button.setEnabled(status)
    
    def load_configuration(self):
        """Load executable and save paths from appsettings.json."""
        config_file = os.path.join(os.path.dirname(__file__), 'appsettings.json')
        try:
            with open(config_file, 'r') as file:
                config = json.load(file)
                executable_paths = config.get("ExecutablePaths", {})
                save_paths = config.get("SavePaths", {})
                return executable_paths, save_paths
        except FileNotFoundError:
            self.show_error(f"Configuration file not found: {config_file}")
            return {}, {}
        except json.JSONDecodeError as e:
            self.show_error(f"Error parsing JSON: {e}")
            return {}, {}
        
    def apply_theme(self):
        """Apply a custom dark theme with better look and feel."""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #2E2E2E;
                color: #F0F0F0;
            }
            QLabel {
                color: #D3D3D3;
                font-size: 14px;
            }
            QLineEdit, QComboBox {
                background-color: #3B3B3B;
                border: 1px solid #5C5C5C;
                padding: 4px;
                color: #E0E0E0;
                border-radius: 4px;
            }
            QPushButton {
                background-color: #5A5A5A;
                border: 1px solid #7E7E7E;
                padding: 6px;
                color: #E0E0E0;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #6C6C6C;
            }
            QPushButton:pressed {
                background-color: #4C4C4C;
            }
            QTreeWidget {
                background-color: #3C3C3C;
                border: 1px solid #5C5C5C;
                color: #F0F0F0;
                border-radius: 4px;
            }
            QHeaderView::section {
                background-color: #5C5C5C;
                padding: 4px;
                border: none;
                font-weight: bold;
                color: #E0E0E0;
            }
        """)

    def browse_file(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Open Solution File", "", "All Files (*);;Project Files (*.csproj *.xml)")
        if file_name:
            self.solution_file_input.setText(file_name)
            self.proceed_button.setEnabled(True)
        else:
            self.proceed_button.setEnabled(False)

    def proceed(self):
             
        self.start_process("Code Analysis in progress, please wait...")        
        solution_type = self.solution_type_combobox.currentText()
        solution_file_path = self.solution_file_input.text()
        new_dot_file_path="";

        if not solution_file_path:
            self.show_error("Solution file path is empty.")
            return    
            
        threading.Thread(target=self.call_CodeAnalysisService,args=(solution_file_path,solution_type)).start()  
        
    def call_CodeAnalysisService(self,solution_file_path,solution_type):
        exe_command = self.get_exe_command(solution_type)
        if exe_command:
            try:
               
                # Run the .exe file and get the new .dot file path 
                arguments=["codeanalysis",solution_file_path]               
                #argument=solution_file_path + ",codeanalysis"
                #result = subprocess.run(f'"{exe_command}" "{argument}"', shell=True, check=True, text=True, capture_output=True)
                # Use subprocess.run to execute the .exe file with arguments
                result = subprocess.run([exe_command] + arguments, shell=True, check=True, text=True, capture_output=True)
                read_stdout_data = result.stdout.strip()
                if read_stdout_data!="Failed" :  
                    responseArray=   read_stdout_data.split("|")
                    new_dot_file_path=   responseArray[0];        
                    self.dot_file_path = new_dot_file_path
                    self.All_ClassAndDependencies_Json_File_Path = responseArray[1];
                

                # Validate and process the new .dot file
                if new_dot_file_path and new_dot_file_path.endswith('.dot'):
                    self.process_file(new_dot_file_path)
                else:
                    self.show_error("The .exe did not generate a valid .dot file.")
            except subprocess.CalledProcessError as e:
                self.show_error(f".exe execution failed: {e}")
                
    def get_exe_command(self, solution_type):
        return self.executable_paths.get(solution_type)

    def louvain_community_detection(self,graph):
        # Step 2: Convert to an undirected graph (necessary for community detection)
        undirected_graph = graph.to_undirected()

        # Step 3: Apply Louvain Method for Community Detection
        partition = community_louvain.best_partition(undirected_graph)

        # # Step 4: Output Communities and Save to JSON
        # print("Detected Communities:")
        # communities = {}
        # for node, community_id in partition.items():
        #     if community_id not in communities:
        #         communities[community_id] = []
        #     communities[community_id].append(node)
        # Create a dictionary to hold communities
        communities = {}
        # Group nodes by community
        for node, community_id in partition.items():
            if community_id not in communities:
                communities[community_id] = set()
            communities[community_id].add(node)

        # Convert the communities dictionary to a list of sets
        community_list = list(communities.values())

        return community_list
    
    def process_file(self, file_path):
        self.dot_file_path=file_path
        self.start_process("Code Analysis in completed, please wait till data get load...")   
        try:            
            G = nx.drawing.nx_pydot.read_dot(file_path)
            #communities = list(greedy_modularity_communities(G))
            communities = self.louvain_community_detection(G)            
            self.display_communities(communities)              
            self.save_communities_as_json(communities, file_path)
            self.save_community_relationship_json()
            self.enable_disable_bottom_buttons(True)             
            self.stop_process()
        except Exception as e:
            self.show_error(f"An error occurred while processing the file: {e}")

    def get_community_name_from_class_names(self,class_names):
        # Step 1: Split class names into individual words and count their occurrences
        word_counter = Counter()        
        for class_name in class_names:
            # Split class name by capital letters or non-alphabetic characters
            words = re.findall(r'[A-Z][a-z]*|[a-z]+', class_name)
            word_counter.update(words)

        # Step 2: Find the most frequent word
        most_common_word, _ = word_counter.most_common(1)[0]
        return most_common_word
    
    def get_max_occurrence_word(self,class_names):
        # Initialize a list to store all words
        words = []        
        # Loop through each class name
        for full_class_name in class_names:
            # Split by dots (.) and uppercase letters using regex
            projectName=full_class_name.split(".",maxsplit=1)[0]
            class_name=full_class_name.split(".")[-1]
            split_words=projectName + class_name
            words.append(split_words)
            # if (len(class_name)>12) :
            #     split_words = re.findall(r'[A-Za-z][a-z]*', class_name)   
            # else :
            #    split_words = class_name         

        # Count occurrences of each word
        word_counts = Counter(words)        
        # Find the most common word
        most_common_word, count = word_counts.most_common(1)[0]        
        return most_common_word, count
    
    def display_communities(self, communities):
        self.results_tree.clear()
        self.original_communities_data = []  # Clear the original data
        objMicroservicesName=MicroserviceNameSuggeestion()
        for i, community in enumerate(communities):
            # Get the most common string in the node array for community labeling
            node_strings = [str(node) for node in community]
            #max_word, count =self.get_max_occurrence_word(node_strings)

            #most_common_string = max_word if node_strings else f"Community {i + 1}"
            most_common_string=objMicroservicesName.generate_community_names(node_strings)[0]
            community_item = QTreeWidgetItem([most_common_string, ""])
            community_item.setFlags(community_item.flags() | Qt.ItemFlag.ItemIsEditable)  # Make the community header editable
            
            nodes_list = []
            for node in community:
                node_item = QTreeWidgetItem([str(node)])
                nodes_list.append(str(node))
                community_item.addChild(node_item)
            self.results_tree.addTopLevelItem(community_item)
            # Store original data for reset
            self.original_communities_data.append((most_common_string, nodes_list))

    def get_communities_as_Json_FilePath(self):
        """Save communities as a JSON file with the same name as the .dot file."""
        base_name = os.path.splitext(os.path.basename(self.dot_file_path))[0]
        base_name="Microservice_suggestion"
        self.community_file_path = os.path.join(os.path.dirname(self.dot_file_path), f"{base_name}.json")
        return self.community_file_path    

    def save_communities_as_json(self, communities, dot_file_path):
        """Save communities as a JSON file with the same name as the .dot file."""
        base_name = os.path.splitext(os.path.basename(dot_file_path))[0]
        base_name="Microservice_suggestion"
        self.community_file_path = os.path.join(os.path.dirname(dot_file_path), f"{base_name}.json")

        try:
            # Convert the communities into a JSON-serializable format
            communities_data = {f"Community {i + 1}": list(map(str, community)) for i, community in enumerate(communities)}
            with open(self.community_file_path, 'w') as json_file:
                json.dump(communities_data, json_file, indent=4)
            print(f"Results saved to {self.community_file_path}")
        except Exception as e:
            self.show_error(f"Error saving results as JSON: {e}")

    def save_community_relationship_json(self):
        """Save communities relationship data as a JSON file with the same name as the .dot file."""
        base_name = os.path.splitext(os.path.basename(self.dot_file_path))[0]
        base_name="Microservice_suggestion"
        self.relationship_json_path = os.path.join(os.path.dirname(self.dot_file_path), f"{base_name}_relationship.json")        
        objNDiagram=PrepareNetworkDiagram()

        try:
            #Step 1: Parse the .dot file
            nodes, edges =objNDiagram.parse_dot_file(self.dot_file_path)

            # Step 2: Load the community JSON file
            community_data = objNDiagram.load_community_json(str(self.community_file_path))

            # Step 3: Prepare the relationship data
            relationship_data = objNDiagram.prepare_relationship_data(nodes, edges, community_data)
            self.community_relationship_data=relationship_data

            # Step 4: Save the relationship data to a JSON file
            objNDiagram.save_relationship_data(relationship_data,str(self.relationship_json_path))

        except Exception as e:
            self.show_error(f"Error saving results as JSON: {e}")

    def handle_item_changed(self, item, column):
        """Handle changes to the community header and autosave the updated value."""
        if column == 0 and self.community_file_path:
            # Update the JSON file when the community name is edited
            self.update_json_file_with_new_label(item)
            self.save_community_relationship_json()

    def update_json_file_with_new_label(self, item):
        """Update the JSON file to reflect the edited community names."""
        try:
            # Read the current community data from the JSON file
            with open(self.community_file_path, 'r') as json_file:
                communities_data = json.load(json_file)
            
            # Find the original community name and update it with the edited label
            new_label = item.text(0)
            community_index = self.results_tree.indexOfTopLevelItem(item)
            original_key = list(communities_data.keys())[community_index]
            
            # Update the key in the JSON structure
            communities_data[new_label] = communities_data.pop(original_key)

            # Save the updated data back to the JSON file
            with open(self.community_file_path, 'w') as json_file:
                json.dump(communities_data, json_file, indent=4)
            print(f"Community header updated in {self.community_file_path}")
        except Exception as e:
            self.show_error(f"Error updating JSON file: {e}")

    def save_tree_to_json(self):
        """Save all data in the TreeView to the JSON file."""
        if not self.community_file_path:
            self.show_error("Required Microservices list to render Relationship Diagram!!!.")
            return False

        try:
            self.start_process(" In progress, please wait...")
            communities_data = {}
            for i in range(self.results_tree.topLevelItemCount()):
                community_item = self.results_tree.topLevelItem(i)
                community_name = community_item.text(0)
                nodes = [community_item.child(j).text(0) for j in range(community_item.childCount())]
                communities_data[community_name] = nodes

            with open(self.community_file_path, 'w') as json_file:
                json.dump(communities_data, json_file, indent=4)
            print(f"TreeView data saved to {self.community_file_path}")  
            
            threading.Thread(target=self.save_community_relationship_json).start();
            self.stop_process();
            return True            

        except Exception as e:
            self.show_error(f"Error saving TreeView data: {e}")
            return False

    def reset_tree_view(self):
        """Reset the TreeView to the original state."""
        if self.original_communities_data is None:
            self.show_error("No original data to reset.")
            return

        self.results_tree.clear()       
        for community_name, nodes in self.original_communities_data:
            community_item = QTreeWidgetItem([community_name, ""])
            community_item.setFlags(community_item.flags() | Qt.ItemFlag.ItemIsEditable)  # Editable header
            for node in nodes:
                node_item = QTreeWidgetItem([node])
                community_item.addChild(node_item)
            self.results_tree.addTopLevelItem(community_item)
       

    def onTabChange(self,i):
        if(i==1):
            self.reload_networktab()        

    def reload_networktab(self):
       if self.save_tree_to_json():
            self.load_community_data()
            self.load_relationship_data()
            self.render_all_network_diagrams()

    def load_community_data(self):
        """Load community data from the _community.json file."""
        if not self.community_file_path:
            self.show_error("No community file path set.")
            return

        try:
            with open(self.community_file_path, 'r') as file:
                self.community_data = json.load(file)
                print("Community data loaded.")
        except FileNotFoundError:
            print("Error: _community.json file not found.")

    def load_relationship_data(self):
        """Load relationship data from the _relationshipData.json file."""
        if not self.community_file_path:
            self.show_error("No community file _relationshipData path set.")
            return
        
        try:
            with open(self.relationship_json_path, 'r') as file:
                self.relationship_data = json.load(file)
                print("Relationship data loaded.")
        except FileNotFoundError:
            print("Error: _relationshipData.json file not found.")

    def render_all_network_diagrams(self):
        """Render all network diagrams in a grid layout."""

        if not self.community_relationship_data:
            self.show_error("No community file relationship_data set.")
            return
        
        self.start_process("In progress, please wait...")
        row, col = 0, 0
        for community, data in self.community_relationship_data.items():
            canvas = self.create_network_canvas(community, data)

            # Set the fixed height for each canvas
            canvas.setFixedHeight(500)

            self.network_tab.diagram_layout.addWidget(canvas, row, col)

            col += 1
            if col >= 1:  # Two columns per row
                col = 0
                row += 1
        self.stop_process()

    def create_network_canvas(self, community, data):
        """Create a network diagram canvas for a given community."""
        G = nx.DiGraph()
        G.add_nodes_from(data['nodes'])
        G.add_edges_from(data['edges'])

        # Create the figure and zoomable canvas
        figure = Figure(figsize=(8, 6), dpi=100)
        ax = figure.add_subplot(111)

        # Use a circular layout for better readability
        pos = nx.circular_layout(G)  # Change layout to circular
        nodes = nx.draw_networkx_nodes(G, pos, ax=ax, node_color='skyblue', node_size=500)
        edges = nx.draw_networkx_edges(G, pos, ax=ax, edge_color='gray', width=0.5)
        labels = nx.draw_networkx_labels(G, pos, ax=ax, font_size=7, font_weight='normal')
        # nx.draw(
        #     G, pos, ax=ax, with_labels=True, node_color='skyblue', edge_color='gray',
        #     node_size=500, font_size=6, font_weight='normal', arrowsize=10,
        #     width=0.5  # Thinner edges
        # )

        ax.set_title(f"Network Diagram for {community}", fontsize=12)
        figure.tight_layout()  # Adjust layout to prevent cut-off labels
        canvas = ZoomableCanvas(figure)

        # Make nodes draggable
        # for node, (x, y) in pos.items():
        #     point = ax.plot([x], [y], 'o', color='skyblue')[0]
        #     text = ax.text(x, y, node, fontsize=6, weight='normal')
        #     canvas.add_draggable(point, text)

        return canvas
    
    def create_microservice_popup(self):
        """Creates a popup window to display the console output."""
        # self.start_process("In progress, please wait...")
        
        solution_type = self.solution_type_combobox.currentText()
        
        solution_file_path = self.solution_file_input.text()

        arguments=["create_microservices",
                   solution_file_path,
                   self.All_ClassAndDependencies_Json_File_Path,
                   self.community_file_path,
                   self.dot_file_path ]
        
        console_popup=QDialog(self)
        console_popup.setWindowTitle("Create Microservice Output")
        console_popup.setMinimumSize(600, 400)
        layout = QVBoxLayout()
        output_text_edit = QTextEdit()        
        output_text_edit.setText("Microservices creation is InProgress, please wait...")
        layout.addWidget(output_text_edit)
        console_popup.setLayout(layout)        
        console_popup.show()
        
        createMicroservice_Thread= threading.Thread(target=self.call_createMicroserviceExe,args=(solution_type,arguments))
        createMicroservice_Thread.start();
        createMicroservice_Thread.join();
        
        output_text_edit.setText(self.create_microservice_console_output)
        output_text_edit.setReadOnly(True)  

    def call_createMicroserviceExe(self,solution_type,arguments):
        exe_command = self.get_exe_command(solution_type)
        if exe_command:
            try:               
                # Execute .exe and get stdout
                process = subprocess.Popen([exe_command] + arguments, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                stdout, stderr = process.communicate()
                self.create_microservice_console_output=stdout+stderr;                
            except Exception as e:
                self.show_error(f"Error executing .exe: {e}")
    
    def show_CreateMicroservicePopup(self):
        # Display the output in a popup window       
        #self.start_process("Microservices created successfully...")
        popup = QDialog(self)
        popup.setWindowTitle("Create Microservice Output")
        popup.setMinimumSize(600, 400)
        layout = QVBoxLayout()
        output_text_edit = QTextEdit()
        output_text_edit.setReadOnly(True)  
        output_text_edit.setText("");              
        layout.addWidget(output_text_edit)
        popup.setLayout(layout)
        return popup
        #popup.exec()
    
    def show_error(self, message,title="Error"):
        self.stop_process()
        error_dialog = QMainWindow(self)
        error_dialog.setWindowTitle(title)
        error_dialog.setMinimumSize(QSize(300, 100))
        error_label = QLabel(message, error_dialog)
        error_label.setWordWrap(True)
        layout = QVBoxLayout(error_dialog)
        layout.addWidget(error_label)
        error_dialog.setCentralWidget(error_label)
        error_dialog.show()

    
    def start_process(self,message="In progress, please wait..."):
        # Show progress bar with custom text        
        # Turn-on the worker thread.
        self.progress_widget.show_progress(message)
        self.progress_widget.progress_bar.show();
       
    def stop_process(self):
        # Hide progress bar
        self.progress_widget.hide_progress()
        self.progress_widget.progress_bar.hide();
        
   
     
if __name__ == "__main__":
    app = QApplication(sys.argv)
    #app.setStyle('Windows')
    apply_stylesheet(app, theme='light_blue.xml')
   
    login_window = LoginWindow()
    login_window.show()
    sys.exit(app.exec())
