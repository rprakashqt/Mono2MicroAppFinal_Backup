﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mono2MicroAppFinal.Common
{
    internal class NugetPackageService
    {

        public void AddNugetPackages()
        {

        }
    }



    internal class NuGetApiSearcher
    {
        private static readonly HttpClient _httpClient = new HttpClient();

        public static async Task SearchPackageAsync(string packageName)
        {
            try
            {
                // Construct the search URL
                string url = $"https://api.nuget.org/v3/registration5-gz-semver2/{packageName.ToLower()}/index.json";

                // Make the HTTP GET request
                var response = await _httpClient.GetAsync(url);

                if (response.IsSuccessStatusCode)
                {
                    var responseBody = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(responseBody); // You can parse this JSON as needed
                }
                else
                {
                    Console.WriteLine($"Failed to retrieve package info. Status code: {response.StatusCode}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error occurred: {ex.Message}");
            }
        }
    }
}
