﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Mono2MicroAppFinal.Common
{
    internal static class CommonServices
    {
        public static string logFilePath { get; set; }

        public static readonly HashSet<string> ReservedKeywords = new HashSet<string>
        {
            "abstract", "as", "base", "bool", "break", "byte", "case", "catch", "char",
            "checked", "class", "const", "continue", "decimal", "default", "delegate",
            "do", "double", "else", "enum", "event", "explicit", "extern", "false",
            "finally", "fixed", "float", "for", "foreach", "goto", "if", "implicit",
            "in", "int", "interface", "internal", "is", "lock", "long", "namespace",
            "new", "null", "object", "operator", "out", "override", "params", "private",
            "protected", "public", "readonly", "ref", "return", "sbyte", "sealed", "short",
            "sizeof", "stackalloc", "static", "string", "struct", "switch", "this", "throw",
            "true", "try", "typeof", "uint", "ulong", "unchecked", "unsafe", "ushort",
            "using", "virtual", "void", "volatile", "while"
        };

        public static bool IsFrameworkClass(string className)
        {
            return className.StartsWith("System.") || className.StartsWith("Microsoft.")
           || className.StartsWith("mscorlib.") || className.StartsWith("netstandard.")
           || className.StartsWith("Windows.") || className.StartsWith("Runtime.")
           || className.StartsWith("PresentationCore.") || className.StartsWith("PresentationFramework.")
           || className.EndsWith("Attribute") || className.EndsWith("Extensions")
           || className.StartsWith("Moq.") || className.Contains("Newtonsoft.")
           || className.Contains("anonymous type");
        }

        public static bool IsExcludeDefaultLibrary(string className)
        {
            return className.StartsWith("System");
        }

        public static bool IsAttribute(string className)
        {
            return className.EndsWith("Attribute");
        }
        public static string GetFileName(string fillFullPath)
        {
            return Path.GetFileNameWithoutExtension(fillFullPath);
        }
        public static void WriteJsonFile(string filePath, string JsonString)
        {
            File.WriteAllText(filePath, JsonString);
        }
        public static string LogFile_Timer()
        {
            DateTime dt = DateTime.Now;
            return dt.Year.ToString() + dt.Month.ToString() + dt.Day.ToString() + dt.Hour.ToString() + dt.Minute.ToString();
        }
        public static T ReadJsonFile<T>(string path)
        {
            try
            {
                string jsonString = File.ReadAllText(path);
                return JsonSerializer.Deserialize<T>(jsonString, JsonSerializerOptions.Default);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return default;
            }
        }
        public static Dictionary<string, List<string>> JsonToDictionary(string path)
        {
            try
            {
                string jsonString = File.ReadAllText(path);
                return JsonSerializer.Deserialize<Dictionary<string, List<string>>>(jsonString);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new Dictionary<string, List<string>>();
            }
        }
        public static void CreateDictory(string baseDirectory)
        {
            if (!Directory.Exists(baseDirectory))
            {
                Directory.CreateDirectory(baseDirectory);
            }
        }
        public static void LogWrite(string logMessage)
        {
            try
            {
                if (string.IsNullOrEmpty(logFilePath)) logFilePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

                using (StreamWriter w = File.AppendText(logFilePath + "\\" + "log.txt"))
                {
                    Log(logMessage, w);
                }
            }
            catch (Exception ex)
            {
            }
        }
        private static void Log(string logMessage, TextWriter txtWriter)
        {
            try
            {
                txtWriter.Write("\r\nLog Entry : ");
                txtWriter.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(),
                    DateTime.Now.ToLongDateString());
                txtWriter.WriteLine("  :");
                txtWriter.WriteLine("  :{0}", logMessage);
                txtWriter.WriteLine("-------------------------------");
            }
            catch (Exception ex)
            {
            }
        }
        public static string GetLastIndexValue(string name, string spliter)
        {
            return name.Split(spliter)?.LastOrDefault();
        }
    }
}
