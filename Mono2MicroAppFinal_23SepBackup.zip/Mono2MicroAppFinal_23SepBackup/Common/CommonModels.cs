﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mono2MicroAppFinal.Common
{
    public class ProjectDependency
    {
        public string ProjectName { get; set; }
        public Dictionary<string, ClassDependency> Classes { get; set; } = new Dictionary<string, ClassDependency>();
    }

    public class ClassDependency
    {
        public string ClassName { get; set; }
        public HashSet<string> Dependencies { get; set; } = new HashSet<string>();
    }

    public class AnalyzeCodeDependencies_Response
    {
        public Dictionary<string, ProjectDependency> dependencies { get; set; }
        public List<ProjectSolutionOverallClassFileNameAndDependecy> overallClassesAndDependencies { get; set; }
    }

    public class ProjectSolutionOverallClassFileNameAndDependecy
    {
        public string ProjectName { get; set; }
        public string ClassName { get; set; }
        public string ClassFullName { get; set; }
        public string ClassFullPath { get; set; }
        public HashSet<string> Dependencies { get; set; } = new HashSet<string>();

    }

    public class MicroserviceSuggestion
    {
        public string MicroserviceName { get; set; }
        public List<string> Components { get; set; }
        public int ControllerCount { get; set; }
        public int ModelCount { get; set; }
        public int ClassCount { get; set; }
        public int InterfaceCount { get; set; }
    }

    // Helper class to parse the NuGet API search response
    public class NuGetSearchResult
    {
        public NuGetPackageData[] data { get; set; }
    }

    public class NuGetPackageData
    {
        public string id { get; set; }
    }

    public class MicroserviceProjectAndAddPackageList
    {
        public string MicroserviceName { get; set; }
        public HashSet<string> PackageNameList { get; set; }

    }
}
